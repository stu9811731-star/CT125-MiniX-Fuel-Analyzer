import {PRESET, DEFAULT_SETTINGS, parseLogText, analyzeLogs, reportToCsv} from './analyzer.js';
import {unzipLoga} from './zip.js';

const $ = s => document.querySelector(s);
const filesEl=$('#files'), drop=$('#drop'), runBtn=$('#run'), result=$('#result'), statusEl=$('#status');
let selected=[]; let latestReport=null;

function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function setStatus(s, bad=false){statusEl.textContent=s;statusEl.className=bad?'bad':'';}
function updateFiles(){
  $('#fileList').innerHTML=selected.length?selected.map(f=>`<span class="chip">${esc(f.name)}</span>`).join(''):'尚未選擇檔案';
  runBtn.disabled=!selected.length;
}
filesEl.addEventListener('change',()=>{selected=[...filesEl.files];updateFiles();});
['dragenter','dragover'].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.add('drag');}));
['dragleave','drop'].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.remove('drag');}));
drop.addEventListener('drop',e=>{selected=[...e.dataTransfer.files].filter(f=>/\.loga(\.zip)?$/i.test(f.name));updateFiles();});
drop.addEventListener('click',()=>filesEl.click());

function getSettings(){ return {
  minEngineTemp:Number($('#minTemp').value),
  entryWaitSeconds:Number($('#entryWait').value),
  minStableSecondsAfterWait:Number($('#minStable').value),
  accExclusionSeconds:Number($('#accWait').value),
  maxSuggestionPct:Number($('#maxSuggest').value)
}; }

async function loadSelected(){
  const logs=[];
  for (const f of selected) {
    if (/\.zip$/i.test(f.name)) {
      const entries=await unzipLoga(await f.arrayBuffer());
      for (const e of entries) logs.push({name:`${f.name}/${e.name}`,rows:parseLogText(e.text,e.name)});
    } else logs.push({name:f.name,rows:parseLogText(await f.text(),f.name)});
  }
  return logs;
}

function fmt(v,n=2){return v==null?'—':Number(v).toFixed(n);}
function badge(v){return `<span class="badge ${String(v).toLowerCase().replaceAll(' ','-')}">${esc(v)}</span>`;}
function render(report){
  latestReport=report; result.hidden=false;
  const s=report.summary;
  $('#summary').innerHTML=`<div><b>${s.cells}</b><span>有效格位</span></div><div><b>${s.adjustCells}</b><span>建議修正</span></div><div><b>${s.verifyCells}</b><span>需驗證</span></div><div><b>${s.totalSamples}</b><span>有效樣本</span></div><div><b>${fmt(s.effectiveSeconds,1)}s</b><span>有效時間</span></div>`;
  const by=new Map(report.cells.map(c=>[`${c.tps}|${c.rpm}`,c]));
  let h='<table class="map"><thead><tr><th>TPS\\RPM</th>'+PRESET.rpmAxis.map(r=>`<th>${r}</th>`).join('')+'</tr></thead><tbody>';
  for(const tps of PRESET.fuelTpsAxis){h+=`<tr><th>${tps}%</th>`;for(const rpm of PRESET.rpmAxis){const c=by.get(`${tps}|${rpm}`);if(!c)h+='<td class="empty">—</td>';else{const cls=c.status==='Adjust'?'adjust':c.status==='Verify'?'verify':c.status==='Monitor only'?'monitor':'';h+=`<td class="${cls}" title="Actual ${c.actualAfrMedian} / Target ${c.targetAfrMedian}; n=${c.samples}"><strong>${c.suggestedCorrectionPct>0?'+':''}${fmt(c.suggestedCorrectionPct,1)}%</strong><small>${esc(c.confidence)}</small></td>`;}}h+='</tr>';}
  h+='</tbody></table>';$('#mapWrap').innerHTML=h;

  $('#detailBody').innerHTML=report.cells.map(c=>`<tr><td>${c.tps}%</td><td>${c.rpm}</td><td>${fmt(c.targetAfrMedian,2)}</td><td>${fmt(c.actualAfrMedian,2)}</td><td>${c.samples}</td><td>${fmt(c.effectiveSeconds,1)}</td><td>${c.segments}</td><td>${fmt(c.theoreticalCorrectionPct,1)}%</td><td><b>${c.suggestedCorrectionPct>0?'+':''}${fmt(c.suggestedCorrectionPct,1)}%</b></td><td>${badge(c.confidence)}</td><td>${badge(c.consistency)}</td><td>${badge(c.status)}</td></tr>`).join('');
  const ex=report.exclusions;$('#quality').innerHTML=Object.entries(ex).map(([k,v])=>`<div><span>${esc(k)}</span><b>${v}</b></div>`).join('');
  $('#anomalies').innerHTML=report.anomalies.length?report.anomalies.map(a=>`<div class="alert"><b>${a.tps}% / ${a.rpm} rpm</b> — ${esc(a.type)} (${fmt(a.value,1)}%)</div>`).join(''):'<div class="ok">未偵測到大型修正或多 Log 明顯衝突。</div>';
}

runBtn.addEventListener('click',async()=>{
  runBtn.disabled=true;setStatus('正在解析與分析…');
  try{const logs=await loadSelected();const report=analyzeLogs(logs,getSettings());render(report);setStatus(`完成：${logs.length} 個 Log，${report.summary.cells} 個有效格位`);}
  catch(e){console.error(e);setStatus(e.message||String(e),true);}
  finally{runBtn.disabled=false;}
});

$('#export').addEventListener('click',()=>{if(!latestReport)return;const blob=new Blob([reportToCsv(latestReport)],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='ct125_fuel_analysis.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);});

if('serviceWorker'in navigator) navigator.serviceWorker.register('./sw.js').catch(console.warn);
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();window._pwaPrompt=e;$('#install').hidden=false;});
$('#install').addEventListener('click',async()=>{const e=window._pwaPrompt;if(!e)return;await e.prompt();window._pwaPrompt=null;$('#install').hidden=true;});

updateFiles();
