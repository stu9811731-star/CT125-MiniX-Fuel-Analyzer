function u16(v,o){ return v.getUint16(o,true); }
function u32(v,o){ return v.getUint32(o,true); }

async function inflateRaw(bytes) {
  if (!('DecompressionStream' in globalThis)) throw new Error('此瀏覽器不支援 ZIP 解壓縮；請直接選擇 .loga，或更新瀏覽器。');
  const ds = new DecompressionStream('deflate-raw');
  const stream = new Blob([bytes]).stream().pipeThrough(ds);
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

export async function unzipLoga(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer), view = new DataView(arrayBuffer);
  let eocd = -1;
  for (let i=bytes.length-22; i>=Math.max(0,bytes.length-65557); i--) {
    if (u32(view,i) === 0x06054b50) { eocd=i; break; }
  }
  if (eocd < 0) throw new Error('無法辨識 ZIP 結構');
  const entries = u16(view,eocd+10), cdOffset = u32(view,eocd+16);
  let p = cdOffset;
  const out=[];
  const decoder = new TextDecoder();
  for (let n=0; n<entries; n++) {
    if (u32(view,p)!==0x02014b50) throw new Error('ZIP 中央目錄損壞');
    const method=u16(view,p+10), compSize=u32(view,p+20), nameLen=u16(view,p+28), extraLen=u16(view,p+30), commentLen=u16(view,p+32), localOffset=u32(view,p+42);
    const name=decoder.decode(bytes.slice(p+46,p+46+nameLen));
    p += 46+nameLen+extraLen+commentLen;
    if (!name.toLowerCase().endsWith('.loga')) continue;
    if (u32(view,localOffset)!==0x04034b50) continue;
    const localNameLen=u16(view,localOffset+26), localExtraLen=u16(view,localOffset+28);
    const start=localOffset+30+localNameLen+localExtraLen;
    const compressed=bytes.slice(start,start+compSize);
    let plain;
    if (method===0) plain=compressed;
    else if (method===8) plain=await inflateRaw(compressed);
    else throw new Error(`${name}: 不支援 ZIP compression method ${method}`);
    out.push({name, text:decoder.decode(plain)});
  }
  if (!out.length) throw new Error('ZIP 內找不到 .loga 檔案');
  return out;
}
