import test from 'node:test';
import assert from 'node:assert/strict';
import {parseLogText,analyzeLogs,temperatureWeight} from '../src/analyzer.js';

function logRows({afr=15.4,target=14.7,tps=40,rpm=4000,temp=80,n=30,accAt=-1,fuelPW=2,fuelCL=1,tempFn=null,afrFn=null}={}) {
  const h='Time,AFR_Target,AFR_WBO2,Fuel_CL,RPM,TPS_Percent,T_Eng,Acc_Fuel_Mult,WBO2_Ready,Cyl1_Comn_FuelPW,Cyl1_Eng_AP,Cyl1_Final_VM,SA';
  const rows=[];
  for(let i=0;i<n;i++){
    const tt=tempFn?tempFn(i):temp;
    const aa=afrFn?afrFn(i):afr;
    rows.push(`${(i/10).toFixed(1)},${target},${aa},${fuelCL},${rpm},${tps},${tt},${i===accAt?0.12:0},1,${fuelPW},70,100,28`);
  }
  return h+'\n'+rows.join('\n');
}

test('AFR correction direction and magnitude',()=>{
  const rows=parseLogText(logRows());
  const c=analyzeLogs([{name:'a.loga',rows}]).cells[0];
  assert.equal(c.theoreticalCorrectionPct,4.76);
  assert.equal(c.suggestedCorrectionPct,4.76);
});

test('TPS 0 monitor only',()=>{
  const rows=parseLogText(logRows({tps:0}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.status,'Monitor only');
  assert.equal(c.suggestedCorrectionPct,0);
});

test('minimum temperature excludes data',()=>{
  const rows=parseLogText(logRows({temp:50}));
  const r=analyzeLogs([{name:'a',rows}]);
  assert.equal(r.cells.length,0);
  assert.equal(r.exclusions.engine_temp,30);
});

test('suggestion clamps at 5 percent but raw V3 remains visible',()=>{
  const rows=parseLogText(logRows({afr:17}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.suggestedCorrectionPct,5);
  assert.ok(c.theoreticalCorrectionPct>5);
});

test('acceleration enrichment excludes one second and splits steady state',()=>{
  const rows=parseLogText(logRows({n:50,accAt:15}));
  const r=analyzeLogs([{name:'a',rows}]);
  assert.ok(r.exclusions.after_acc_fuel>=10);
});

test('multi log disagreement becomes Verify',()=>{
  const a=parseLogText(logRows({afr:15.4,n:35}));
  const b=parseLogText(logRows({afr:13.7,n:35}));
  const c=analyzeLogs([{name:'a',rows:a},{name:'b',rows:b}]).cells[0];
  assert.equal(c.consistency,'Mixed');
  assert.equal(c.status,'Verify');
  assert.equal(c.suggestedCorrectionPct,0);
});

test('MiniX millisecond Time auto-normalizes to seconds',()=>{
  const h='Time,AFR_Target,AFR_WBO2,RPM,TPS_Percent,T_Eng,Acc_Fuel_Mult,Cyl1_Comn_FuelPW';
  const rows=parseLogText(h+'\n0,14.7,15.0,4000,40,80,0,2\n100,14.7,15.0,4000,40,80,0,2\n200,14.7,15.0,4000,40,80,0,2');
  assert.equal(rows[1].time,0.1);
  assert.equal(rows.meta.timeScale,0.001);
});

test('90-100C has highest temperature weight',()=>{
  assert.ok(temperatureWeight(95)>temperatureWeight(85));
  assert.ok(temperatureWeight(95)>temperatureWeight(105));
  assert.ok(temperatureWeight(95)>temperatureWeight(70));
});

test('temperature weighted correction influences V3 blended result',()=>{
  const rows=parseLogText(logRows({
    n:40,
    tempFn:i=>i<20?70:95,
    afrFn:i=>i<20?15.0:15.8,
    target:14.7
  }));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  const unweighted=((15.0/14.7-1)*100*15 + (15.8/14.7-1)*100*20)/35;
  assert.ok(c.weightedCorrectionPct>unweighted);
  assert.ok(c.theoreticalCorrectionPct>unweighted);
});

test('Fuel_CL support does not create correction alone',()=>{
  const rows=parseLogText(logRows({afr:14.7,target:14.7,fuelCL:6,n:35}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.theoreticalCorrectionPct,0);
  assert.equal(c.suggestedCorrectionPct,0);
  assert.equal(c.fuelClEvidence,'CL only');
});

test('Fuel_CL opposite direction forces Verify',()=>{
  const rows=parseLogText(logRows({afr:15.4,target:14.7,fuelCL:-4,n:35}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.fuelClEvidence,'Conflicts');
  assert.equal(c.status,'Verify');
  assert.equal(c.suggestedCorrectionPct,0);
});

test('V3 sample thresholds are strict greater-than',()=>{
  // 15 accepted samples after the 0.5s entry wait: 3% class must be >15, so no adjust.
  const rows=parseLogText(logRows({afr:15.2,target:14.7,n:20})); // raw ~3.4%; first 5 wait => 15 accepted
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.samples,15);
  assert.equal(c.status,'Monitor');
});

test('High confidence requires at least 30 accepted samples',()=>{
  const short=parseLogText(logRows({afr:15.4,n:30})); // accepted ~25
  const c1=analyzeLogs([{name:'a',rows:short}]).cells[0];
  assert.notEqual(c1.confidence,'High');
  const long=parseLogText(logRows({afr:15.4,n:70}));
  const c2=analyzeLogs([{name:'a',rows:long}]).cells[0];
  assert.equal(c2.samples>=30,true);
});
