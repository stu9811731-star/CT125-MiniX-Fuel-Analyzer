const CACHE='ct125-fuel-v3.4.1';
const VERSION='v=3.4.1';
const ASSETS=[
  './',
  `./index.html?${VERSION}`,
  `./guide.html?${VERSION}`,
  `./tuning.html?${VERSION}`,
  `./faq.html?${VERSION}`,
  `./styles.css?${VERSION}`,
  `./views.css?${VERSION}`,
  `./manifest.webmanifest?${VERSION}`,
  `./src/app.js?${VERSION}`,
  `./src/analyzer.js?${VERSION}`,
  `./src/zip.js?${VERSION}`,
  './assets/icon.svg',
  './assets/icon-192.svg'
];

self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting()));
});

self.addEventListener('activate',event=>{
  event.waitUntil(
    caches.keys()
      .then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key))))
      .then(()=>self.clients.claim())
  );
});

self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;

  if(event.request.mode==='navigate'){
    event.respondWith(
      fetch(event.request)
        .then(response=>{
          if(response.ok){
            const copy=response.clone();
            caches.open(CACHE).then(cache=>cache.put(event.request,copy));
          }
          return response;
        })
        .catch(()=>caches.match(event.request).then(cached=>cached||caches.match(`./index.html?${VERSION}`)))
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{
      if(response.ok){
        const copy=response.clone();
        caches.open(CACHE).then(cache=>cache.put(event.request,copy));
      }
      return response;
    }))
  );
});
