export const PRESET = {
  name: 'Honda CT125 JA65 / MiniX',
  fuelTpsAxis: [0,2,4,6,8,10,15,20,25,30,40,50,60,70,80,90,100],
  afrIgnTpsAxis: [0,2,5,10,20,40,60,80,100],
  rpmAxis: [800,1600,2400,3200,4000,4800,5600,6400,7200,8000,8800,9600]
};

export const DEFAULT_SETTINGS = {
  minEngineTemp: 65,
  accExclusionSeconds: 1.0,
  entryWaitSeconds: 0.5,
  minStableSecondsAfterWait: 0.5,
  maxSuggestionPct: 5,
  minAfr: 8,
  maxAfr: 25,
  tpsZeroMonitorOnly: true,
  accFuelTolerance: 0.002,
  fuelClSupportThreshold: 2,
  highConfidenceMinSamples: 30,
  timeUnit: 'auto'
};

const FIELD_ALIASES = {
  time: ['Time','time','Timestamp','timestamp','Sec','Seconds','LogTime'],
  afrTarget: ['AFR_Target','AFR Target','Target_AFR','Target AFR'],
  afrActual: ['AFR_WBO2','AFR WBO2','WBO2_AFR','Wideband_AFR','AFR'],
  fuelCL: ['Fuel_CL','Fuel CL','FuelCL'],
  rpm: ['RPM','Engine_RPM','Eng_RPM'],
  tps: ['TPS_Percent','TPS Percent','TPS','Throttle_Percent'],
  temp: ['T_Eng','T Eng','Engine_Temp','ECT'],
  accFuel: ['Acc_Fuel_Mult','Acc Fuel Mult','Accel_Fuel_Mult'],
  finalVM: ['Cyl1_Final_VM','Final_VM','Cyl1 Final VM'],
  fuelPW: ['Cyl1_Comn_FuelPW','Comn_FuelPW','FuelPW','Injector_PW'],
  map: ['Cyl1_Eng_AP','Eng_AP','MAP','Manifold_Pressure'],
  sa: ['SA','Spark_Angle','Ignition_Angle'],
  wbo2Ready: ['WBO2_Ready','WBO2 Ready','WBO2Ready','Wideband_Ready','AFR_Ready']
};

function normalizeHeader(s) {
  return String(s ?? '').trim().replace(/^\uFEFF/, '').toLowerCase().replace(/[^a-z0-9]+/g, '');
}

function detectDelimiter(line) {
  const candidates = [',','\t',';'];
  let best = ',', bestCount = -1;
  for (const c of candidates) {
    const n = line.split(c).length;
    if (n > bestCount) { best = c; bestCount = n; }
  }
  return best;
}

function splitDelimited(line, delimiter) {
  const out = [];
  let cur = '', quoted = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (quoted && line[i+1] === '"') { cur += '"'; i++; }
      else quoted = !quoted;
    } else if (ch === delimiter && !quoted) {
      out.push(cur); cur = '';
    } else cur += ch;
  }
  out.push(cur);
  return out.map(v => v.trim());
}

function parseNum(v) {
  if (v == null || v === '') return null;
  const n = Number(String(v).trim().replace('%',''));
  return Number.isFinite(n) ? n : null;
}

function parseReady(v) {
  if (v == null || v === '') return null;
  const s = String(v).trim().toLowerCase();
  if (['1','true','ready','yes','ok','on'].includes(s)) return true;
  if (['0','false','notready','no','off','invalid'].includes(s)) return false;
  const n = Number(s);
  return Number.isFinite(n) ? n > 0 : null;
}

function median(values) {
  if (!values.length) return null;
  const a = [...values].sort((x,y)=>x-y);
  const m = Math.floor(a.length/2);
  return a.length%2 ? a[m] : (a[m-1]+a[m])/2;
}
function mean(values) { return values.length ? values.reduce((a,b)=>a+b,0)/values.length : null; }
function weightedMean(values, weights) {
  let sw=0, sx=0;
  for (let i=0;i<values.length;i++) {
    const v=values[i], w=weights[i];
    if (!Number.isFinite(v) || !Number.isFinite(w) || w<=0) continue;
    sx += v*w; sw += w;
  }
  return sw>0 ? sx/sw : null;
}
function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
function round(x, n=2) { return x == null ? null : Number(x.toFixed(n)); }
function stddev(values) {
  if (values.length < 2) return null;
  const m = mean(values);
  return Math.sqrt(mean(values.map(v => (v-m)**2)));
}

export function temperatureWeight(temp) {
  if (!Number.isFinite(temp)) return 1;
  if (temp >= 90 && temp <= 100) return 1.50;
  if ((temp >= 80 && temp < 90) || (temp > 100 && temp <= 110)) return 1.20;
  if (temp > 110) return 0.85;
  return 1.00;
}

export function parseLogText(text, sourceName='log') {
  const lines = String(text).replace(/\r/g,'').split('\n').filter(x => x.trim().length);
  if (lines.length < 2) throw new Error(`${sourceName}: 找不到足夠的資料列`);

  let headerIndex = -1, delimiter = ',';
  for (let i=0; i<Math.min(lines.length, 80); i++) {
    const d = detectDelimiter(lines[i]);
    const headers = splitDelimited(lines[i], d).map(normalizeHeader);
    const hasRpm = FIELD_ALIASES.rpm.some(a => headers.includes(normalizeHeader(a)));
    const hasTps = FIELD_ALIASES.tps.some(a => headers.includes(normalizeHeader(a)));
    if (hasRpm && hasTps) { headerIndex = i; delimiter = d; break; }
  }
  if (headerIndex < 0) throw new Error(`${sourceName}: 找不到 RPM/TPS 欄位標題`);

  const rawHeaders = splitDelimited(lines[headerIndex], delimiter);
  const normalized = rawHeaders.map(normalizeHeader);
  const col = {};
  for (const [key, aliases] of Object.entries(FIELD_ALIASES)) {
    col[key] = aliases.map(normalizeHeader).map(a => normalized.indexOf(a)).find(i => i >= 0) ?? -1;
  }
  const required = ['afrTarget','afrActual','rpm','tps','temp'];
  const missing = required.filter(k => col[k] < 0);
  if (missing.length) throw new Error(`${sourceName}: 缺少必要欄位 ${missing.join(', ')}`);

  const rawRows = [];
  let fallbackTime = 0;
  for (let i=headerIndex+1; i<lines.length; i++) {
    const cells = splitDelimited(lines[i], delimiter);
    if (cells.length < Math.max(...Object.values(col)) + 1) continue;
    const get = k => col[k] >= 0 ? cells[col[k]] : null;
    let t = parseNum(get('time'));
    if (t == null) { t = fallbackTime; fallbackTime += 0.1; }
    const row = {
      sourceName,
      line: i+1,
      time: t,
      afrTarget: parseNum(get('afrTarget')),
      afrActual: parseNum(get('afrActual')),
      fuelCL: parseNum(get('fuelCL')),
      rpm: parseNum(get('rpm')),
      tps: parseNum(get('tps')),
      temp: parseNum(get('temp')),
      accFuel: parseNum(get('accFuel')),
      finalVM: parseNum(get('finalVM')),
      fuelPW: parseNum(get('fuelPW')),
      map: parseNum(get('map')),
      sa: parseNum(get('sa')),
      wbo2Ready: parseReady(get('wbo2Ready'))
    };
    if (row.rpm != null && row.tps != null) rawRows.push(row);
  }
  rawRows.sort((a,b)=>a.time-b.time);
  if (!rawRows.length) throw new Error(`${sourceName}: 沒有可解析的資料`);

  // MiniX .loga commonly records Time in milliseconds (0,100,200...).
  const diffs=[];
  for(let i=1;i<Math.min(rawRows.length,300);i++){
    const d=rawRows[i].time-rawRows[i-1].time;
    if(Number.isFinite(d)&&d>0) diffs.push(d);
  }
  const dtMedian=median(diffs);
  const timeScale=(dtMedian!=null && dtMedian>=10) ? 0.001 : 1;
  if(timeScale!==1) for(const r of rawRows) r.time*=timeScale;
  rawRows.meta={sourceName,headerIndex:headerIndex+1,timeScale,rawRows:rawRows.length,medianRawInterval:dtMedian};
  return rawRows;
}

export function nearestAxis(value, axis) {
  if (value == null) return null;
  let best = axis[0], d = Math.abs(value-axis[0]);
  for (let i=1; i<axis.length; i++) {
    const nd = Math.abs(value-axis[i]);
    if (nd < d) { best = axis[i]; d = nd; }
  }
  return best;
}

function rowInterval(rows, i) {
  if (i < rows.length-1) return Math.max(0, rows[i+1].time - rows[i].time);
  if (i > 0) return Math.max(0, rows[i].time - rows[i-1].time);
  return 0;
}

function qualityGate(row, settings, lastAccTime) {
  if (row.temp == null || row.temp < settings.minEngineTemp) return 'engine_temp';
  if (row.afrTarget == null || row.afrActual == null) return 'afr_missing';
  if (row.afrActual < settings.minAfr || row.afrActual > settings.maxAfr) return 'wbo2_range';
  if (row.wbo2Ready === false) return 'wbo2_not_ready';
  if (row.fuelPW != null && row.fuelPW <= 0.001) return 'fuel_cut';
  if (lastAccTime != null && row.time - lastAccTime <= settings.accExclusionSeconds + 1e-9) return 'after_acc_fuel';
  return null;
}

// V3: strict "more than" sample counts.
function thresholdPass(absPct, samples) {
  if (absPct >= 7) return samples > 10;
  if (absPct >= 3) return samples > 15;
  if (absPct >= 2) return samples > 20;
  return false;
}

function fuelClEvidence(correctionPct, fuelClMedian, settings) {
  if (!Number.isFinite(fuelClMedian) || Math.abs(fuelClMedian) < settings.fuelClSupportThreshold) return 'Neutral';
  if (!Number.isFinite(correctionPct) || Math.abs(correctionPct) < 0.5) return 'CL only';
  return Math.sign(fuelClMedian) === Math.sign(correctionPct) ? 'Supports' : 'Conflicts';
}

function confidenceFor(cell, settings) {
  let score = 0;
  if (cell.samples >= 60) score += 3;
  else if (cell.samples >= settings.highConfidenceMinSamples) score += 2;
  else if (cell.samples > 20) score += 1;

  if (cell.effectiveSeconds >= 5) score += 2;
  else if (cell.effectiveSeconds >= 2) score += 1;

  if (cell.segments >= 4) score += 2;
  else if (cell.segments >= 2) score += 1;

  if (cell.consistency === 'Consistent') score += 2;
  else if (cell.consistency === 'Single log') score += 1;

  if (cell.afrStdDev != null && cell.afrStdDev <= 0.30) score += 1;
  if (cell.fuelClEvidence === 'Supports') score += 1;
  if (cell.fuelClEvidence === 'Conflicts') score -= 2;

  // High is never assigned below 30 samples.
  if (cell.samples >= settings.highConfidenceMinSamples && score >= 7) return 'High';
  if (score >= 4) return 'Medium';
  return 'Low';
}

function correctionStats(rows) {
  const valid = rows.filter(r => Number.isFinite(r.afrActual) && Number.isFinite(r.afrTarget) && r.afrTarget > 0);
  const errors = valid.map(r => (r.afrActual/r.afrTarget - 1)*100);
  const weights = valid.map(r => temperatureWeight(r.temp));
  const med = median(errors);
  const wmean = weightedMean(errors, weights);
  // AFR Target/WBO2 remains primary. Median and temperature-weighted mean are equally combined.
  const robust = (med != null && wmean != null) ? (med+wmean)/2 : (med ?? wmean);
  return {errors, medianCorrection:med, weightedCorrection:wmean, robustCorrection:robust};
}

export function analyzeLogs(logs, userSettings={}) {
  const settings = {...DEFAULT_SETTINGS, ...userSettings};
  const exclusions = {
    engine_temp:0, afr_missing:0, wbo2_range:0, wbo2_not_ready:0,
    fuel_cut:0, after_acc_fuel:0, entry_wait:0, short_segment:0
  };
  const segments = [];
  const anomalies = [];
  const diagnostics = {logs:logs.length, rawRows:0, tempPass:0, afrPass:0, accelPass:0, gatePass:0, afterEntryWait:0, acceptedSamples:0};

  for (const log of logs) {
    const rows = log.rows ?? log;
    diagnostics.rawRows += rows.length;
    const sourceName = log.name ?? rows[0]?.sourceName ?? 'log';
    let lastAccTime = null;
    let current = null;

    const flush = () => {
      if (!current) return;
      const usableDuration = current.rows.length ? current.rows.reduce((s,x)=>s+x.dt,0) : 0;
      if (usableDuration + 1e-9 < settings.minStableSecondsAfterWait) {
        exclusions.short_segment += current.rows.length;
      } else if (current.rows.length) {
        segments.push({...current, duration: usableDuration, sourceName});
      }
      current = null;
    };

    for (let i=0; i<rows.length; i++) {
      const row = rows[i];
      if (row.temp != null && row.temp >= settings.minEngineTemp) diagnostics.tempPass++;
      if (row.temp != null && row.temp >= settings.minEngineTemp && row.afrTarget != null && row.afrActual != null &&
          row.afrActual >= settings.minAfr && row.afrActual <= settings.maxAfr && row.wbo2Ready !== false) diagnostics.afrPass++;

      // MiniX baseline is zero. A non-zero multiplier marks acceleration enrichment.
      const accActive = row.accFuel != null && Math.abs(row.accFuel) > settings.accFuelTolerance;
      if (accActive) lastAccTime = row.time;
      if (!accActive) diagnostics.accelPass++;

      const gate = qualityGate(row, settings, lastAccTime);
      if (gate) { exclusions[gate]++; flush(); continue; }
      diagnostics.gatePass++;

      const tpsBin = nearestAxis(row.tps, PRESET.fuelTpsAxis);
      const rpmBin = nearestAxis(row.rpm, PRESET.rpmAxis);
      const key = `${tpsBin}|${rpmBin}`;
      if (!current || current.key !== key) {
        flush();
        current = { key, tps:tpsBin, rpm:rpmBin, enteredAt:row.time, rows:[] };
      }
      const sinceEntry = row.time - current.enteredAt;
      if (sinceEntry + 1e-9 < settings.entryWaitSeconds) {
        exclusions.entry_wait++;
        continue;
      }
      diagnostics.afterEntryWait++;
      current.rows.push({row, dt:rowInterval(rows,i)});
    }
    flush();
  }

  const byCell = new Map();
  for (const seg of segments) {
    if (!byCell.has(seg.key)) byCell.set(seg.key, []);
    byCell.get(seg.key).push(seg);
  }

  diagnostics.acceptedSamples = segments.reduce((n,s)=>n+s.rows.length,0);

  const cells = [];
  for (const [key, segs] of byCell) {
    const rows = segs.flatMap(s=>s.rows.map(x=>x.row));
    const actuals = rows.map(r=>r.afrActual).filter(Number.isFinite);
    const targets = rows.map(r=>r.afrTarget).filter(Number.isFinite);
    const temps = rows.map(r=>r.temp).filter(Number.isFinite);
    const actualMedian = median(actuals), targetMedian = median(targets);
    const stats = correctionStats(rows);
    const theoretical = stats.robustCorrection;

    const actualWeighted = weightedMean(actuals, rows.filter(r=>Number.isFinite(r.afrActual)).map(r=>temperatureWeight(r.temp)));
    const targetWeighted = weightedMean(targets, rows.filter(r=>Number.isFinite(r.afrTarget)).map(r=>temperatureWeight(r.temp)));

    const perLog = new Map();
    for (const s of segs) {
      if (!perLog.has(s.sourceName)) perLog.set(s.sourceName, []);
      perLog.get(s.sourceName).push(...s.rows.map(x=>x.row));
    }
    const logCorrections = [...perLog.entries()].map(([name, rs]) => {
      const st = correctionStats(rs);
      return {name, correctionPct:st.robustCorrection, samples:rs.length};
    }).filter(x=>x.correctionPct != null);

    let consistency = 'Single log';
    if (logCorrections.length > 1) {
      const signs = new Set(logCorrections.filter(x=>Math.abs(x.correctionPct)>=0.5).map(x=>Math.sign(x.correctionPct)));
      const vals = logCorrections.map(x=>x.correctionPct);
      const spread = Math.max(...vals) - Math.min(...vals);
      consistency = signs.size <= 1 && spread <= 3 ? 'Consistent' : 'Mixed';
    }

    const fuelClMedian = median(rows.map(r=>r.fuelCL).filter(Number.isFinite));
    const clEvidence = fuelClEvidence(theoretical, fuelClMedian, settings);

    let suggestion = 0, status = 'Monitor';
    if (theoretical != null && thresholdPass(Math.abs(theoretical), rows.length)) {
      suggestion = clamp(theoretical, -settings.maxSuggestionPct, settings.maxSuggestionPct);
      status = 'Adjust';
    }
    const [tps,rpm] = key.split('|').map(Number);
    if (settings.tpsZeroMonitorOnly && tps === 0) { suggestion = 0; status = 'Monitor only'; }
    if (consistency === 'Mixed') { status = 'Verify'; suggestion = 0; }
    // Fuel_CL is supporting evidence only; it never creates a correction by itself.
    if (clEvidence === 'Conflicts' && Math.abs(theoretical ?? 0) >= 2) { status = 'Verify'; suggestion = 0; }

    const cell = {
      tps, rpm,
      targetAfrMedian: round(targetMedian,3),
      targetAfrWeighted: round(targetWeighted,3),
      actualAfrMedian: round(actualMedian,3),
      actualAfrWeighted: round(actualWeighted,3),
      actualAfrMean: round(mean(actuals),3),
      afrStdDev: round(stddev(actuals),3),
      tempMedian: round(median(temps),1),
      tempWeightedShare90to100: round(
        rows.length ? rows.filter(r=>Number.isFinite(r.temp) && r.temp>=90 && r.temp<=100).length/rows.length*100 : 0, 1
      ),
      fuelClMedian: round(fuelClMedian,2),
      fuelClEvidence: clEvidence,
      mapMedian: round(median(rows.map(r=>r.map).filter(Number.isFinite)),2),
      fuelPwMedian: round(median(rows.map(r=>r.fuelPW).filter(Number.isFinite)),3),
      finalVmMedian: round(median(rows.map(r=>r.finalVM).filter(Number.isFinite)),3),
      saMedian: round(median(rows.map(r=>r.sa).filter(Number.isFinite)),2),
      samples: rows.length,
      effectiveSeconds: round(segs.reduce((s,x)=>s+x.duration,0),2),
      segments: segs.length,
      medianCorrectionPct: round(stats.medianCorrection,2),
      weightedCorrectionPct: round(stats.weightedCorrection,2),
      theoreticalCorrectionPct: round(theoretical,2),
      suggestedCorrectionPct: round(suggestion,2),
      consistency,
      status,
      logCorrections: logCorrections.map(x=>({...x, correctionPct:round(x.correctionPct,2)}))
    };
    cell.confidence = confidenceFor(cell, settings);
    cells.push(cell);

    if (Math.abs(theoretical ?? 0) >= 8 || consistency === 'Mixed' || clEvidence === 'Conflicts') {
      const type = consistency === 'Mixed' ? 'multi_log_mismatch' : clEvidence === 'Conflicts' ? 'fuel_cl_conflict' : 'large_correction';
      anomalies.push({type, tps, rpm, value:round(theoretical,2), fuelClMedian:round(fuelClMedian,2)});
    }
  }

  cells.sort((a,b)=>a.tps-b.tps || a.rpm-b.rpm);
  return {
    preset: PRESET.name,
    algorithmVersion: 'V3',
    settings,
    cells,
    exclusions,
    segments: segments.length,
    anomalies,
    diagnostics,
    summary: {
      cells: cells.length,
      adjustCells: cells.filter(c=>c.status==='Adjust').length,
      verifyCells: cells.filter(c=>c.status==='Verify').length,
      highConfidenceCells: cells.filter(c=>c.confidence==='High').length,
      totalSamples: cells.reduce((s,c)=>s+c.samples,0),
      effectiveSeconds: round(cells.reduce((s,c)=>s+c.effectiveSeconds,0),2)
    }
  };
}

export function reportToCsv(report) {
  const cols = [
    'TPS','RPM','Target AFR median','Target AFR weighted','Actual AFR median','Actual AFR weighted',
    'Samples','Effective sec','Segments','Temp median','90-100C share %','MAP','FuelPW','Final_VM','SA',
    'AFR median correction %','Temp-weighted correction %','V3 blended correction %','Suggested %',
    'Fuel_CL median','Fuel_CL evidence','Confidence','Consistency','Status'
  ];
  const rows = report.cells.map(c => [
    c.tps,c.rpm,c.targetAfrMedian,c.targetAfrWeighted,c.actualAfrMedian,c.actualAfrWeighted,
    c.samples,c.effectiveSeconds,c.segments,c.tempMedian,c.tempWeightedShare90to100,c.mapMedian,c.fuelPwMedian,c.finalVmMedian,c.saMedian,
    c.medianCorrectionPct,c.weightedCorrectionPct,c.theoreticalCorrectionPct,c.suggestedCorrectionPct,
    c.fuelClMedian,c.fuelClEvidence,c.confidence,c.consistency,c.status
  ]);
  return [cols,...rows].map(r=>r.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(',')).join('\n');
}
