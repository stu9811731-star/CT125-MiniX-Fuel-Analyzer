import {PRESET, DEFAULT_SETTINGS, parseLogText, analyzeLogs, reportToCsv} from './analyzer.js';
import {unzipLoga} from './zip.js';

const $ = s => document.querySelector(s);
const filesEl=$('#files'), drop=$('#drop'), runBtn=$('#run'), result=$('#result'), statusEl=$('#status');
let selected=[]; let latestReport=null;

function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function setStatus(s, bad=false){statusEl.textContent=s;statusEl.className=bad?'bad':'';}
function updateFiles(){
  $('#fileList').innerHTML=selected.length?selected.map(f=>`<span class="chip">${esc(f.name)}</span>`).join(''):'尚未選擇檔案';
  runBtn.disabled=!selected.length;
}
filesEl.addEventListener('change',()=>{selected=[...filesEl.files];updateFiles();});
['dragenter','dragover'].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.add('drag');}));
['dragleave','drop'].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.remove('drag');}));
drop.addEventListener('drop',e=>{selected=[...e.dataTransfer.files].filter(f=>/\.loga(\.zip)?$/i.test(f.name));updateFiles();});
drop.addEventListener('click',()=>filesEl.click());

function getSettings(){ return {
  minEngineTemp:Number($('#minTemp').value),
  entryWaitSeconds:Number($('#entryWait').value),
  minStableSecondsAfterWait:Number($('#minStable').value),
  accExclusionSeconds:Number($('#accWait').value),
  maxSuggestionPct:Number($('#maxSuggest').value)
}; }

async function loadSelected(){
  const logs=[];
  for (const f of selected) {
    if (/\.zip$/i.test(f.name)) {
      const entries=await unzipLoga(await f.arrayBuffer());
      for (const e of entries) logs.push({name:`${f.name}/${e.name}`,rows:parseLogText(e.text,e.name)});
    } else logs.push({name:f.name,rows:parseLogText(await f.text(),f.name)});
  }
  return logs;
}

function fmt(v,n=2){return v==null?'—':Number(v).toFixed(n);}
function signed(v,n=1){if(v==null)return'—';const x=Number(v);return `${x>0?'+':''}${x.toFixed(n)}%`;}
function badge(v){return `<span class="badge ${String(v).toLowerCase().replaceAll(' ','-')}">${esc(v)}</span>`;}
function clLabel(v){return ({Supports:'同向支持',Conflicts:'方向衝突',Neutral:'中性','CL only':'僅 CL'})[v]||v;}

function render(report){
  latestReport=report; result.hidden=false;
  const s=report.summary;
  $('#summary').innerHTML=
    `<div><b>${s.cells}</b><span>有效格位</span></div>`+
    `<div><b>${s.adjustCells}</b><span>建議修正</span></div>`+
    `<div><b>${s.verifyCells}</b><span>需驗證</span></div>`+
    `<div><b>${s.highConfidenceCells}</b><span>高可信格位</span></div>`+
    `<div><b>${s.totalSamples}</b><span>有效樣本</span></div>`+
    `<div><b>${fmt(s.effectiveSeconds,1)}s</b><span>有效時間</span></div>`;

  const by=new Map(report.cells.map(c=>[`${c.tps}|${c.rpm}`,c]));
  let h='<table class="map"><thead><tr><th>TPS\\RPM</th>'+PRESET.rpmAxis.map(r=>`<th>${r}</th>`).join('')+'</tr></thead><tbody>';
  for(const tps of PRESET.fuelTpsAxis){
    h+=`<tr><th>${tps}%</th>`;
    for(const rpm of PRESET.rpmAxis){
      const c=by.get(`${tps}|${rpm}`);
      if(!c){h+='<td class="empty">—</td>';continue;}
      const cls=c.status==='Adjust'?'adjust':c.status==='Verify'?'verify':c.status==='Monitor only'?'monitor':'';
      let main='—', sub=`原始 ${signed(c.theoreticalCorrectionPct,1)} · N=${c.samples}`;
      if(c.status==='Adjust') main=signed(c.suggestedCorrectionPct,1);
      else if(c.status==='Verify') main='驗證';
      else if(c.status==='Monitor only') main='監看';
      h+=`<td class="${cls}" title="Target ${c.targetAfrMedian} / Actual ${c.actualAfrMedian}; raw ${c.theoreticalCorrectionPct}%; n=${c.samples}; Fuel_CL ${c.fuelClMedian ?? '—'}">`+
         `<strong>${main}</strong><small>${sub}</small><small>${esc(c.confidence)}</small></td>`;
    }
    h+='</tr>';
  }
  h+='</tbody></table>';
  $('#mapWrap').innerHTML=h;

  $('#detailBody').innerHTML=report.cells.map(c=>`<tr>`+
    `<td>${c.tps}%</td><td>${c.rpm}</td>`+
    `<td>${fmt(c.targetAfrMedian,2)}</td><td>${fmt(c.actualAfrMedian,2)}</td>`+
    `<td>${c.samples}</td><td>${fmt(c.effectiveSeconds,1)}</td><td>${c.segments}</td>`+
    `<td>${signed(c.medianCorrectionPct,1)}</td><td>${signed(c.weightedCorrectionPct,1)}</td>`+
    `<td><b>${signed(c.theoreticalCorrectionPct,1)}</b></td>`+
    `<td><b>${c.status==='Adjust'?signed(c.suggestedCorrectionPct,1):'—'}</b></td>`+
    `<td>${fmt(c.fuelClMedian,1)}%</td><td>${badge(clLabel(c.fuelClEvidence))}</td>`+
    `<td>${badge(c.confidence)}</td><td>${badge(c.consistency)}</td><td>${badge(c.status)}</td>`+
    `</tr>`).join('');

  const d=report.diagnostics||{};
  $('#diagnostics').innerHTML=[
    ['原始資料',d.rawRows],['溫度 ≥ 門檻',d.tempPass],['AFR/WBO2 合格',d.afrPass],
    ['非加速補油當下',d.accelPass],['品質閘門通過',d.gatePass],['進格等待後',d.afterEntryWait],
    ['最終有效樣本',d.acceptedSamples]
  ].map(([k,v])=>`<div><span>${esc(k)}</span><b>${v??0}</b></div>`).join('');

  const labels={
    engine_temp:'低於引擎溫度門檻',afr_missing:'AFR 資料缺失',wbo2_range:'WBO2 超出合理範圍',
    wbo2_not_ready:'WBO2 未就緒',fuel_cut:'斷油 / FuelPW≈0',after_acc_fuel:'加速補油後排除',
    entry_wait:'進格等待',short_segment:'等待後有效時間不足'
  };
  $('#quality').innerHTML=Object.entries(report.exclusions).map(([k,v])=>`<div><span>${esc(labels[k]||k)}</span><b>${v}</b></div>`).join('');

  $('#anomalies').innerHTML=report.anomalies.length?report.anomalies.map(a=>{
    const type=({multi_log_mismatch:'多 Log 不一致',large_correction:'原始修正幅度過大',fuel_cl_conflict:'Fuel_CL 與 AFR 方向衝突'})[a.type]||a.type;
    return `<div class="alert"><b>${a.tps}% / ${a.rpm} rpm</b> — ${esc(type)}（AFR ${signed(a.value,1)}${a.fuelClMedian!=null?`；Fuel_CL ${signed(a.fuelClMedian,1)}`:''}）</div>`;
  }).join(''):'<div class="ok">未偵測到大型修正、多 Log 明顯衝突或 Fuel_CL 方向衝突。</div>';
}

runBtn.addEventListener('click',async()=>{
  runBtn.disabled=true;setStatus('正在解析與執行 V3 分析…');
  try{
    const logs=await loadSelected();
    const report=analyzeLogs(logs,getSettings());
    render(report);
    setStatus(`完成：${logs.length} 個 Log，${report.summary.cells} 個有效格位，${report.summary.adjustCells} 格建議修正`);
  }catch(e){console.error(e);setStatus(e.message||String(e),true);}
  finally{runBtn.disabled=false;}
});

$('#export').addEventListener('click',()=>{
  if(!latestReport)return;
  const blob=new Blob(['\uFEFF'+reportToCsv(latestReport)],{type:'text/csv;charset=utf-8'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);a.download='ct125_fuel_analysis_v3.csv';a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
});

let deferredPrompt=null;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;$('#install').hidden=false;});
$('#install').addEventListener('click',async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$('#install').hidden=true;});
if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(console.warn);
