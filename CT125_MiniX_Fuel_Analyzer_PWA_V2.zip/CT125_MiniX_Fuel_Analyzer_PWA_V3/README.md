# CT125 / SuperXX & MiniXX Log Analyzer PWA V3

針對 Honda CT125 JA65 + SuperXX / MiniXX 的瀏覽器端 Log 分析器。Log 在裝置本機解析，不上傳伺服器。

## ECU 格數與安全限制
- MiniXX：Fuel Map `20×17`、Ignition Map `20×9`。
- SuperXX：Fuel Map `56×25`、Ignition Map `40×17`。
- SuperXX 的 RPM/TPS 軸可在 SpeedTuningX 自訂。未提供 ECU 實際軸值前，工具只顯示等距資料分布預覽，燃油建議會標記 `Axis setup required` 且保持 0%，避免對錯格。
- 「實際點火角」頁讀取 Log 的 `SA` 欄位，顯示暖機後的中位數、平均、最小、最大、波動、樣本數與有效秒數；這不是基礎點火表，也不會提供點火修正建議。

## V3 核心規則
- `.loga` / `.loga.zip`，支援多 Log 合併。
- MiniXX RPM 軸：800～9600，共 20 格。
- MiniXX Fuel TPS 軸：0 / 2 / 4 / 6 / 8 / 10 / 15 / 20 / 25 / 30 / 40 / 50 / 60 / 70 / 80 / 90 / 100%。
- T_Eng ≥65°C。
- 90–100°C 樣本權重最高；80–90°C 與 100–110°C 次之。
- `Acc_Fuel_Mult` 正常基準為 0；非 0 觸發後排除 1 秒。
- 斷油 / FuelPW≈0 排除。
- 進格等待 0.5 秒，等待後至少 0.5 秒有效資料。
- AFR Target + AFR WBO2 是修正主依據。
- 每格同時使用「AFR 誤差中位數」與「溫度加權平均」，V3 原始修正 = 兩者等權合成。
- `Fuel_CL` 絕對值 ≥2% 時只作支持/衝突證據，不單獨產生修正。
- V3 建議門檻：
  - |誤差| ≥7% 且樣本 N >10
  - |誤差| ≥3% 且 N >15
  - |誤差| ≥2% 且 N >20
- N ≥30 才可能標記為 High confidence。
- 單次建議預設限制 ±5%，但畫面另外保留 V3 原始誤差，避免看不到被截斷前的幅度。
- TPS 0% 只監看，不自動建議。
- 多 Log 方向/幅度明顯不一致，或 Fuel_CL 與 AFR 修正方向衝突，標記 Verify 並停止自動建議。

## V3 UI 改進
每個 Fuel Map 格位會顯示：
- 可執行建議（例如 +5.0%）
- V3 原始誤差（例如原始 +8.3%）
- 樣本數 N
- 可信度

明細表另外顯示：
- AFR Target / Actual
- 中位數誤差
- 溫度加權誤差
- V3 合成誤差
- Fuel_CL 中位數與支持/衝突判斷
- 多 Log 一致性

## 部署
GitHub Pages / HTTPS 即可。Service Worker cache key 為 `ct125-fuel-v3.4.1`；頁面與模組使用版本參數，避免舊快取混用新介面。

## 測試
```bash
npm test
```
