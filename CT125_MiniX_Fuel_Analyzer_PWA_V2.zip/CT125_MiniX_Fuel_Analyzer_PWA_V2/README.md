# CT125 / MiniX Fuel Analyzer PWA V1

可安裝在手機或桌面的 Progressive Web App。分析在瀏覽器本機完成，不把 Log 上傳到伺服器。

## 支援
- `.loga`、`.loga.zip`
- 多 Log 合併與一致性判斷
- Honda CT125 JA65 / MiniX preset
- TPS × RPM Fuel Map
- T_Eng >= 65°C
- WBO2 無效排除
- 斷油排除（FuelPW <= 0）
- Acc_Fuel_Mult 觸發後 1 秒排除
- 進格等待 0.5 秒，等待後至少 0.5 秒有效資料
- 修正公式 `(AFR_actual / AFR_target - 1) * 100`
- V3 樣本門檻：>=7% / 10 samples、>=3% / 15、>=2% / 20
- 單次建議限制 ±5%
- TPS 0% 只監看
- SA 點火角只顯示，不修改
- CSV 匯出
- Service Worker 離線快取

## 本機啟動

```bash
cd CT125_MiniX_Fuel_Analyzer_PWA_V1
python3 -m http.server 8000
```

瀏覽器開啟 `http://127.0.0.1:8000`。

> PWA / Service Worker 在 `localhost` 可以使用；部署時請使用 HTTPS。

## 測試

不需要 pytest。本版前端分析核心使用 JavaScript，測試用 Node 內建 test runner：

```bash
npm test
```

## iPhone 安裝

部署到 HTTPS 網址後，用 Safari 開啟 → 分享 →「加入主畫面」。第一次載入後，靜態程式可離線開啟。Log 分析也在本機完成。

## Android / Chrome 安裝

開啟部署網址後可使用瀏覽器的「安裝應用程式」或頁面內的「安裝 App」按鈕。

## 注意

這個 V1 依照既定規格重建。上一個 Codex 工作區的 Python 原始檔在本次執行環境不可直接取得，因此未逐行重用原本 `analyzer.py`。在正式作為調校依據前，建議用已人工確認的實際 Log 建立 golden-data regression tests，逐格比對預期結果。


## V2 fixes
- MiniX Time auto-detection: millisecond logs (0,100,200...) are normalized to seconds.
- Acc_Fuel_Mult baseline corrected to 0; non-zero values are treated as acceleration enrichment.
- Added parsing/filter diagnostics in the UI.
