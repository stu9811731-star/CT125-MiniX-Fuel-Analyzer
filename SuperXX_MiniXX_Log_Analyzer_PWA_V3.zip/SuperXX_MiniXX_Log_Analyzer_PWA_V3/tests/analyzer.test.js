import test from 'node:test';
import assert from 'node:assert/strict';
import {parseLogText,analyzeLogs,analyzeIgnition,getEcuProfile,ignitionToCsv,temperatureWeight} from '../src/analyzer.js';

function logRows({afr=15.4,target=14.7,tps=40,rpm=4000,temp=80,n=30,accAt=-1,fuelPW=2,fuelCL=1,sa=28,tempFn=null,afrFn=null}={}) {
  const h='Time,AFR_Target,AFR_WBO2,Fuel_CL,RPM,TPS_Percent,T_Eng,Acc_Fuel_Mult,WBO2_Ready,Cyl1_Comn_FuelPW,Cyl1_Eng_AP,Cyl1_Final_VM,SA';
  const rows=[];
  for(let i=0;i<n;i++){
    const tt=tempFn?tempFn(i):temp;
    const aa=afrFn?afrFn(i):afr;
    rows.push(`${(i/10).toFixed(1)},${target},${aa},${fuelCL},${rpm},${tps},${tt},${i===accAt?0.12:0},1,${fuelPW},70,100,${sa}`);
  }
  return h+'\n'+rows.join('\n');
}

test('AFR correction direction and magnitude',()=>{
  const rows=parseLogText(logRows());
  const c=analyzeLogs([{name:'a.loga',rows}]).cells[0];
  assert.equal(c.theoreticalCorrectionPct,4.76);
  assert.equal(c.suggestedCorrectionPct,4.76);
});

test('TPS 0 monitor only',()=>{
  const rows=parseLogText(logRows({tps:0}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.status,'Monitor only');
  assert.equal(c.suggestedCorrectionPct,0);
});

test('minimum temperature excludes data',()=>{
  const rows=parseLogText(logRows({temp:50}));
  const r=analyzeLogs([{name:'a',rows}]);
  assert.equal(r.cells.length,0);
  assert.equal(r.exclusions.engine_temp,30);
});

test('suggestion clamps at 5 percent but raw V3 remains visible',()=>{
  const rows=parseLogText(logRows({afr:17}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.suggestedCorrectionPct,5);
  assert.ok(c.theoreticalCorrectionPct>5);
});

test('acceleration enrichment excludes one second and splits steady state',()=>{
  const rows=parseLogText(logRows({n:50,accAt:15}));
  const r=analyzeLogs([{name:'a',rows}]);
  assert.ok(r.exclusions.after_acc_fuel>=10);
});

test('multi log disagreement becomes Verify',()=>{
  const a=parseLogText(logRows({afr:15.4,n:35}));
  const b=parseLogText(logRows({afr:13.7,n:35}));
  const c=analyzeLogs([{name:'a',rows:a},{name:'b',rows:b}]).cells[0];
  assert.equal(c.consistency,'Mixed');
  assert.equal(c.status,'Verify');
  assert.equal(c.suggestedCorrectionPct,0);
});

test('MiniX millisecond Time auto-normalizes to seconds',()=>{
  const h='Time,AFR_Target,AFR_WBO2,RPM,TPS_Percent,T_Eng,Acc_Fuel_Mult,Cyl1_Comn_FuelPW';
  const rows=parseLogText(h+'\n0,14.7,15.0,4000,40,80,0,2\n100,14.7,15.0,4000,40,80,0,2\n200,14.7,15.0,4000,40,80,0,2');
  assert.equal(rows[1].time,0.1);
  assert.equal(rows.meta.timeScale,0.001);
});

test('90-100C has highest temperature weight',()=>{
  assert.ok(temperatureWeight(95)>temperatureWeight(85));
  assert.ok(temperatureWeight(95)>temperatureWeight(105));
  assert.ok(temperatureWeight(95)>temperatureWeight(70));
});

test('temperature weighted correction influences V3 blended result',()=>{
  const rows=parseLogText(logRows({
    n:40,
    tempFn:i=>i<20?70:95,
    afrFn:i=>i<20?15.0:15.8,
    target:14.7
  }));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  const unweighted=((15.0/14.7-1)*100*15 + (15.8/14.7-1)*100*20)/35;
  assert.ok(c.weightedCorrectionPct>unweighted);
  assert.ok(c.theoreticalCorrectionPct>unweighted);
});

test('Fuel_CL support does not create correction alone',()=>{
  const rows=parseLogText(logRows({afr:14.7,target:14.7,fuelCL:6,n:35}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.theoreticalCorrectionPct,0);
  assert.equal(c.suggestedCorrectionPct,0);
  assert.equal(c.fuelClEvidence,'CL only');
});

test('Fuel_CL opposite direction forces Verify',()=>{
  const rows=parseLogText(logRows({afr:15.4,target:14.7,fuelCL:-4,n:35}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.fuelClEvidence,'Conflicts');
  assert.equal(c.status,'Verify');
  assert.equal(c.suggestedCorrectionPct,0);
});

test('V3 sample thresholds are strict greater-than',()=>{
  // 15 accepted samples after the 0.5s entry wait: 3% class must be >15, so no adjust.
  const rows=parseLogText(logRows({afr:15.2,target:14.7,n:20})); // raw ~3.4%; first 5 wait => 15 accepted
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.samples,15);
  assert.equal(c.status,'Monitor');
});

test('High confidence requires at least 30 accepted samples',()=>{
  const short=parseLogText(logRows({afr:15.4,n:30})); // accepted ~25
  const c1=analyzeLogs([{name:'a',rows:short}]).cells[0];
  assert.notEqual(c1.confidence,'High');
  const long=parseLogText(logRows({afr:15.4,n:70}));
  const c2=analyzeLogs([{name:'a',rows:long}]).cells[0];
  assert.equal(c2.samples>=30,true);
});

test('ECU profiles use the documented fuel and ignition grid dimensions',()=>{
  const mini=getEcuProfile('MiniXX');
  assert.equal(mini.fuelRpmAxis.length,20);
  assert.equal(mini.fuelTpsAxis.length,17);
  assert.equal(mini.ignitionRpmAxis.length,20);
  assert.equal(mini.ignitionTpsAxis.length,9);

  const superXX=getEcuProfile('SuperXX');
  assert.equal(superXX.fuelRpmAxis.length,56);
  assert.equal(superXX.fuelTpsAxis.length,25);
  assert.equal(superXX.ignitionRpmAxis.length,40);
  assert.equal(superXX.ignitionTpsAxis.length,17);
  assert.equal(superXX.variableAxes,true);
});

test('fuel analysis uses the selected ECU model grid',()=>{
  const rows=parseLogText(logRows({n:40}));
  const report=analyzeLogs([{name:'superxx.loga',rows}],{ecuModel:'SuperXX'});
  assert.equal(report.settings.ecuModel,'SuperXX');
  assert.equal(report.grid.fuel,'56×25');
  assert.equal(report.axes.fuelRpmAxis.length,56);
  assert.equal(report.axes.fuelTpsAxis.length,25);
  assert.equal(report.cells[0].status,'Axis setup required');
  assert.equal(report.cells[0].suggestedCorrectionPct,0);
});

test('actual ignition analysis reads SA and uses the MiniXX 20×9 map',()=>{
  const rows=parseLogText(logRows({n:30,sa:27.5}));
  const report=analyzeIgnition([{name:'mini.loga',rows}],{ecuModel:'MiniXX'});
  assert.equal(report.grid,'20×9');
  assert.equal(report.cells.length,1);
  assert.equal(report.cells[0].actualSaMedian,27.5);
  assert.equal(report.cells[0].actualSaMin,27.5);
  assert.equal(report.cells[0].actualSaMax,27.5);
  assert.equal(report.summary.acceptedRows,30);
});

test('ignition CSV identifies ECU model and actual SA values',()=>{
  const rows=parseLogText(logRows({sa:31.25}));
  const report=analyzeIgnition([{name:'mini.loga',rows}],{ecuModel:'MiniXX'});
  const csv=ignitionToCsv(report);
  assert.match(csv,/ECU Model/);
  assert.match(csv,/MiniXX/);
  assert.match(csv,/31\.25/);
});

test('ignition-only log can be parsed without AFR columns',()=>{
  const text='Time,RPM,TPS_Percent,T_Eng,SA\n0,4000,40,80,26\n0.1,4000,40,80,28';
  const rows=parseLogText(text,'ignition-only.loga');
  const report=analyzeIgnition([{name:'ignition-only.loga',rows}],{ecuModel:'MiniXX'});
  assert.equal(report.cells[0].actualSaMedian,27);
  assert.equal(report.cells[0].effectiveSeconds,0.1);
});

test('ignition analysis excludes engine-off and out-of-axis samples',()=>{
  const text='Time,RPM,TPS_Percent,T_Eng,Cyl1_Comn_FuelPW,SA\n0,0,0,80,2,5\n0.1,4000,40,80,0,28\n0.2,4000,40,80,2,30';
  const rows=parseLogText(text,'quality.loga');
  const report=analyzeIgnition([{name:'quality.loga',rows}],{ecuModel:'MiniXX'});
  assert.equal(report.summary.acceptedRows,1);
  assert.equal(report.summary.exclusions.outOfAxis,1);
  assert.equal(report.summary.exclusions.fuelCut,1);
});

test('unsupported ECU model is rejected instead of silently using MiniXX',()=>{
  assert.throws(()=>getEcuProfile('UnknownXX'),/不支援的 ECU 型號/);
});
