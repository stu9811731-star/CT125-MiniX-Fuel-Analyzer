function u16(v,o){ return v.getUint16(o,true); }
function u32(v,o){ return v.getUint32(o,true); }

const MAX_ARCHIVE_BYTES = 25 * 1024 * 1024;
const MAX_ENTRIES = 100;
const MAX_ENTRY_COMPRESSED_BYTES = 10 * 1024 * 1024;
const MAX_ENTRY_UNCOMPRESSED_BYTES = 25 * 1024 * 1024;
const MAX_TOTAL_UNCOMPRESSED_BYTES = 50 * 1024 * 1024;

function hasRange(bytes, offset, length) {
  return Number.isSafeInteger(offset) && Number.isSafeInteger(length) && offset >= 0 && length >= 0 && offset + length <= bytes.length;
}

async function inflateRaw(bytes) {
  if (!('DecompressionStream' in globalThis)) throw new Error('此瀏覽器不支援 ZIP 解壓縮；請直接選擇 .loga，或更新瀏覽器。');
  const ds = new DecompressionStream('deflate-raw');
  const stream = new Blob([bytes]).stream().pipeThrough(ds);
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

export async function unzipLoga(arrayBuffer) {
  if (arrayBuffer.byteLength > MAX_ARCHIVE_BYTES) throw new Error('ZIP 檔案超過 25 MB 上限');
  const bytes = new Uint8Array(arrayBuffer), view = new DataView(arrayBuffer);
  let eocd = -1;
  for (let i=bytes.length-22; i>=Math.max(0,bytes.length-65557); i--) {
    if (u32(view,i) === 0x06054b50) { eocd=i; break; }
  }
  if (eocd < 0) throw new Error('無法辨識 ZIP 結構');
  const entries = u16(view,eocd+10), cdOffset = u32(view,eocd+16);
  if (entries > MAX_ENTRIES) throw new Error(`ZIP 項目過多（上限 ${MAX_ENTRIES}）`);
  if (!hasRange(bytes, cdOffset, 0)) throw new Error('ZIP 中央目錄位置無效');
  let p = cdOffset;
  const out=[]; let totalUncompressed = 0;
  const decoder = new TextDecoder();
  for (let n=0; n<entries; n++) {
    if (!hasRange(bytes, p, 46) || u32(view,p)!==0x02014b50) throw new Error('ZIP 中央目錄損壞');
    const flags=u16(view,p+8), method=u16(view,p+10), compSize=u32(view,p+20), plainSize=u32(view,p+24), nameLen=u16(view,p+28), extraLen=u16(view,p+30), commentLen=u16(view,p+32), localOffset=u32(view,p+42);
    if (!hasRange(bytes, p + 46, nameLen + extraLen + commentLen)) throw new Error('ZIP 項目範圍無效');
    const name=decoder.decode(bytes.slice(p+46,p+46+nameLen));
    p += 46+nameLen+extraLen+commentLen;
    if (!name.toLowerCase().endsWith('.loga')) continue;
    if (flags & 1) throw new Error(`${name}: 不支援加密 ZIP 項目`);
    if (compSize > MAX_ENTRY_COMPRESSED_BYTES || plainSize > MAX_ENTRY_UNCOMPRESSED_BYTES || totalUncompressed + plainSize > MAX_TOTAL_UNCOMPRESSED_BYTES) throw new Error(`${name}: 解壓後資料超過安全上限`);
    if (!hasRange(bytes, localOffset, 30) || u32(view,localOffset)!==0x04034b50) throw new Error(`${name}: ZIP 本機項目損壞`);
    const localNameLen=u16(view,localOffset+26), localExtraLen=u16(view,localOffset+28);
    const start=localOffset+30+localNameLen+localExtraLen;
    if (!hasRange(bytes, start, compSize)) throw new Error(`${name}: 壓縮資料範圍無效`);
    const compressed=bytes.slice(start,start+compSize);
    let plain;
    if (method===0) plain=compressed;
    else if (method===8) plain=await inflateRaw(compressed);
    else throw new Error(`${name}: 不支援 ZIP compression method ${method}`);
    if (plain.byteLength !== plainSize) throw new Error(`${name}: 解壓後大小不符`);
    totalUncompressed += plain.byteLength;
    out.push({name, text:decoder.decode(plain)});
  }
  if (!out.length) throw new Error('ZIP 內找不到 .loga 檔案');
  return out;
}
